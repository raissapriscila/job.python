# le a cotação do dólar e o valor em dólares
cotacao_dolar = float(input('digite a cotação do dólar:'))
valor_dolares = float(input('digite o valor em dólares:'))

# calcula o valor em reais reais
valor_reais = cotacao_dolar * valor_dolares

# mostra o resultado
print(f'o valor equivalente em reais é: R${valor_reais:.2f}')


