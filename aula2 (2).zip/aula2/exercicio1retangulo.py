#solicitar os lados do retângulo ( converte para numero decimal)

lado1 = float(input('digite o valor do primeiro lado:'))
lado2 = float(input('digite o valor do segundo lado:'))

#calcule o perimetro (soma de todos os lados) e área ( produto do lado)

perimetro = 2* (lado1 + lado2)
area = lado1 * lado2

#mostra os resultados

print('perímetro:', perimetro)
print('area:', area)