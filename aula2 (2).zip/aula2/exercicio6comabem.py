# Lê o gasto realizado pelo cliente
gasto_cliente = float(input("Digite o valor do gasto realizado: R$ "))

# Calcula o valor total com 10% de gorjeta
valor_total = gasto_cliente * 1.10

# Mostra o resultado
print(f"O valor total a ser pago (com 10% de gorjeta) é: R$ {valor_total:.2f}")