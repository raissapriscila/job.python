import math

# Lê os coeficientes a, b e c
a = float(input("Digite o valor de a: "))
b = float(input("Digite o valor de b: "))
c = float(input("Digite o valor de c: "))

# Calcula delta e as raízes
delta = b ** 2 - 4 * a * c
raiz1 = (-b + math.sqrt(delta)) / (2 * a)
raiz2 = (-b - math.sqrt(delta)) / (2 * a)

# Mostra resultados
print(f"Delta = {delta:.2f}")
print(f"Primeira raiz: {raiz1:.2f}")
print(f"Segunda raiz: {raiz2:.2f}")