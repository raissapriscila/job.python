profissão = input('digite sua profissõa:')
print(profissão)
