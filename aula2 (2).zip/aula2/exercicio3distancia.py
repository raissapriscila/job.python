#solicita distância e tempo, converter para decimal
distancia = float(input('digite as distancia entre as cidades (em km):'))
tempo = float(input('digite o tempo de viagem (em horas):'))

#calcule velocidade média com a formula fornecida 
velocidade_media = distancia/tempo

#mostrar o resultado
print('velocidade média:', velocidade_media, 'km/h')
