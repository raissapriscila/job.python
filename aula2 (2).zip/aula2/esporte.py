esporte = input('esporte favorito:')
print(esporte)