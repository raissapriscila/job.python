# Lê a temperatura em graus Celsius
temperatura_celsius = float(input("Digite a temperatura em graus Celsius: "))

# Calcula as temperaturas nas outras escalas
temperatura_fahrenheit = 1.8 * temperatura_celsius + 32
temperatura_kelvin = temperatura_celsius + 273

# Mostra os resultados
print(f"Temperatura em Fahrenheit: {temperatura_fahrenheit:.1f} °F")
print(f"Temperatura em Kelvin: {temperatura_kelvin} K")