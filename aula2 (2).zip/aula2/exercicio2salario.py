#solicite o salario atual e converte para decimal 

salario_atual = float(input('digite o salario atual:'))

#calcula o salario com 5% de comissão ( 105% do valor original)

salario_acrescido = salario_atual * 1.05

#mostrar o resultado 

print('salario com comissão:', salario_acrescido)
